// This code is hard-coded for solving 2-objective, 30-variable ZDT1 problem
// using eps-MOEA. However, the functions can be changed. 
// For details on eps-MOEA concept, refer to the EMO-03 Conference
// Proceedings paper:
//
// Deb, K., Mohan, M. and Mishra, S. (2003).
// Towards a quick computation of well-spread Pareto-optimal solutions.
// Proceedings of the Second Evolutionary Multi-Criterion
// Optimization (EMO-03) Conference, 8-11 April, Faro, Portugal. 222--236.
// (Also Lecture Notes in Computer Science (LNCS) 2632).
// 
// For a better C code, use the other code (eps-moea.c and accompanying 
// source files) kept on the web site
// http://www.iitk.ac.in/kangal/soft.htm
//
// Any bugs can be reported to Kalyanmoy Deb (deb@iitk.ac.in)
// 
#include <iostream.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define INFINITY 1e7
#define DELTA 1e-6
#define PI 4.0*atan(1.0)

// Number of decision variables
#define N_of_x 30

// MAX is the number of objective functions
#define MAX 2

//MAX_CONSTRAINT is the maximum number of constraints
#define MAX_CONSTRAINT 0

//MAX_ARCHIVE_SIZE is the maximum size possible (the upper bound) of the archive
#define MAX_ARCHIVE_SIZE 1000

// Define the EPSILON matrix
double EPSILON[MAX] = {0.0075, 0.0075};
// any additional constants etc. are defined here

/* declaring the global variables*/

// Define the initial Population Size (to be kept constant throughout the algo.)
const int pop_size = 100;
int max_no_gen;
double pxover;
double eeta, n_distribution_m, p_mutation_real;
int archive_size = 0;    //starting archive size = 0
double seed;
double infimumx[N_of_x];
double supremumx[N_of_x];

// Class definitions for an individual
class individual
{
    public:
        double xreal[N_of_x];
        double gxm;        // value of the g(x) function for the DTLZ-1 problem
        double f[MAX];        // the objective functions
        double cv;        // cv - parameter for constraint violation
        double gxv;
        double box[MAX];        // box vectors for the individual
        double constraint[MAX_CONSTRAINT];    // defining the constraint values
        double gx(){
    double gx_val;
    double sum=0;
    for (int i=1;i<N_of_x ;i++){
      sum+= xreal[i];
    }
    //if ( sum ==0)
    //cout<<" 0000000";
    gx_val= 1+ ( (9 * sum ) / ( N_of_x -1 ) ) ;
    //if (gx_val ==1 )
    //cout<<" ajkfljk";
    return (gx_val);
  }

  double function1() {
    return (xreal[0]);
  }

  double function2(){
    double val_func=0.0,gxval=0.0;
    gxval=gxv;
    val_func=gxval*( 1 - sqrt(xreal[0]/gxval) );
    //if (val_ind == 0)
    //            cout<<gxval<<"\t"<<val_func<<"\n";
    return val_func;
  }
  void init(){
    gxv=gx();
    f[0]=function1();
    f[1]=function2();
  }
};

individual population[pop_size];
individual archive[MAX_ARCHIVE_SIZE];
individual newchild, newchild1, newchild2;

#include "random.h"
#include "realmut.h"
#include "realcross.h"
#include "input.h"

void box_func (individual * ind1);    // prototype of the box function

// Create the random pop
void create_random_pop ()
{
    double ran;
    for (int i = 0; i < pop_size; i++)
    {
        for (int j = 0; j < N_of_x; j++)
        {
            ran = randomperc ();
            population[i].xreal[j] = ran * supremumx[j] + (1.0 - ran) * infimumx[j];
        }
        population[i].init ();
    }
}

// Strict Domination check function for population members indexed by m and n
// returns 1 ( 0 ) meaning m dominates (does not dominate) n in minimization sense
// only for population members _to_be_called_in_  create_archive()
int
strict_dom_check (int m, int n)
{
  int flag = 1;
  for (int p = 0; p < MAX; p++)
    {
      if ((flag == 1) && (population[m].f[p] < population[n].f[p]))
    flag = 1;
      else
    {
      flag = 0;
      break;
    }
    }
  return (flag);
}


// Create the initial archive
// Consists of the non-dominated (strict domination) members
// of the population
void
create_archive ()
{
  int flag = 0;
  for (int i = 0; i < pop_size; i++)
    {
      flag = 0;
      for (int j = 0; j < pop_size; j++)
    {
      if (strict_dom_check (j, i) == 1)
        flag = -1;
    }
      if (flag == 0)
    {
      archive[archive_size] = population[i];
      archive_size++;
    }
    }
}



// Prints the population members, whenever called
void
print_pop ()
{
  cout << "\n Printing real values of the function values\n";
  for (int i = 0; i < pop_size; i++)
    {
      for (int j = 0; j < MAX; j++)
    cout << population[i].f[j] << "\t";
      cout << "\n";
    }
}


// Prints the function values of the archive members, when called
void
print_archive ()
{
  cout << "\n Printing the function values of the archive members\n";
  for (int i = 0; i < archive_size; i++)
    {
      for (int j = 0; j < MAX; j++)
    cout << archive[i].f[j] << "\t";
      cout << "\n";
    }
}


// Prints into files the population and archive members
// Also prints the Box vectors and Decision Variables of the archive members
void
print_func_values ()
{
  FILE *fpop, *farch, *fvar, *fbox;
  fpop = fopen ("popltn.out", "w");
  farch = fopen ("a", "w");
  fvar = fopen ("ar_variables.out", "w");
  fbox = fopen ("box_vectors.out", "w");
  cout << "\n\n The size of the archive is " << archive_size << "\n";
  cout << " The final archive is in file archive.out\n\n";
  for (int i = 0; i < pop_size; i++)
    {
      for (int j = 0; j < MAX; j++)
    fprintf (fpop, "%f\t", population[i].f[j]);
      fprintf (fpop, "\n");
    }
  for (int i = 0; i < archive_size; i++)
    {
      for (int j = 0; j < MAX; j++)
    {
      fprintf (farch, "%f\t", archive[i].f[j]);
      fprintf (fbox, "%f\t", archive[i].box[j] * EPSILON[j]);
    }

      for (int j = 0; j < N_of_x; j++)
    fprintf (fvar, "%f\t", archive[i].xreal[j]);

      fprintf (farch, "\n");
      fprintf (fbox, "\n");
      fprintf (fvar, "\n");
    }
}


// Main function starts here
int
main (int argc, char **argv)
{

  void generate_replace ();
  void compete ();
  int update ();

  // returns 0 if not accepted and 1 if the child is accepted
  int con_update ();

  time_t start, end;
  time (&start);
  // Take the start time reading

  int child_flag1 = 0, flg = 0, child_flag2 = 0;

  input_param ();
  // Input the necessary parameters

//   cout << "\n Enter the seed : ";
//   cin >> seed;
  seed = (double)atof(argv[1]);
  warmup_random (seed);
  // set up the random no. generator

  create_random_pop ();
  create_archive ();

//   cout << "\n Enter the No of Generations Needed : ";
  // No of function evaluations = max_no_gen * 2
//   cin >> max_no_gen;
  max_no_gen = (int)atoi(argv[2]);

  cout << "\n Starting loop........";
  for (int no_gen = 0; no_gen < max_no_gen; no_gen++)
    {
      generate_replace ();
      cout << "\n GEN = " << no_gen + 1;
      cout << "\n NO of members in Archive at present :" << archive_size <<
    "\n";
      newchild = newchild1;
      child_flag1 = con_update ();
      compete ();
      newchild = newchild2;
      child_flag2 = con_update ();
      compete ();
    }
  /* printing the values of the functions */
  print_func_values ();
  time (&end);
  cout << "\n\n Total Time taken == " << difftime (end,
                           start) << " seconds.\n\n";


  return (0);
}

// Box funtion definitons, here done for minimization case
void
box_func (individual * ind1)
{
  for (int i = 0; i < MAX; i++)
    ind1->box[i] = floor ((ind1->f[i] / EPSILON[i]));
}


// function to check for Box domination
int
box_dom (individual ind1, individual ind2)
{
  int flag = 1;
  int elag = 0;
  for (int j = 0; j < MAX; j++)
    {
      if ((flag == 1) && (ind1.box[j] <= ind2.box[j]))
    flag = 1;
      else
    flag = 0;

      if ((ind1.box[j] < ind2.box[j]) || (elag == 1))
    elag = 1;
    }
  if ((flag == 1) && (elag == 1))
    return 1;
  else
    return 0;
}


//to check whether 2 individuals are in the same box or not
int
same_box_check (individual ind1, individual ind2)
{
  int flag = 1;
  for (int i = 0; i < MAX; i++)
    {
      if ((flag == 1) && (ind1.box[i] == ind2.box[i]))
    {
      flag = 1;
    }
      else
    {
      flag = 0;
      break;
    }
    }
  return (flag);
}

// Check for domination (usual sense)
int
dom_check (individual ind1, individual ind2)
{
  int flag = 1;
  int elag = 0;
  for (int j = 0; j < MAX; j++)
    {
      if ((flag == 1) && (ind1.f[j] <= ind2.f[j]))
    flag = 1;
      else
    flag = 0;

      if ((ind1.f[j] < ind2.f[j]) || (elag == 1))
    elag = 1;
    }
  if ((flag == 1) && (elag == 1))
    return 1;
  else
    return 0;
}

// Finds the distance between corner[] and between the decision variable
// coordinates of the individual
double
distance (individual ind1, double point[MAX])
{
  double dist = 0.0;
  for (int i = 0; i < MAX; i++)
    {
      dist += pow ((ind1.f[i] - point[i]), 2);
    }
  dist = sqrt (dist);
  return (dist);
}



int
con_update ()
{
  int flg = 0, d = 0;
  int update ();

  // First Case : the new Child is a feasible solution,
  // i.e. it has zero constraint violation
  if (newchild.cv <= DELTA)
    {
      // removing all infeasible solutions from the archive
      for (int i = 0; i < archive_size; i++)
    {
      if (archive[i].cv > DELTA)
        {
          for (int j = i; j < archive_size - 1; j++)
        {
          archive[j] = archive[j + 1];
        }
          archive_size--;
          d = 1; // set flag to indicate that some archive members have been deleted
        }
    }
      // insert the new child in the usual manner into the archive after
      // removing the infeasible points.
      flg = update ();
    }
  else
    {
      // Second Case : New child is infeasible
      for (int k = 0; k < archive_size; k++)
    {
      if (newchild.cv > archive[k].cv)
        {
          flg = -1;  // reject the child, as there is a better solution in the archive
        }
    }
      if (flg == 0)
    {
      // removing all those members whose constraint violation
      // is higher than that of the new child
      for (int k = 0; k < archive_size; k++)
        {
          if (newchild.cv < archive[k].cv)
        {
          for (int j = k; j < archive_size - 1; j++)
            {
              archive[j] = archive[j + 1];
            }
          archive_size--;
          d = 1; // set flag to indicate that some archive members have been deleted
        }
        }
    }

      if (flg == 0)
    {
      archive_size++;
      archive[archive_size - 1] = newchild;
      // new child inserted into archive
      flg=1; // flag to indicate this
    }
    }
  return (flg);
}




// The Update function, called to update the archive in every iteration
int
update ()
{
  int d = 0, ch_flag = 0, accept_flag, i = 0, no_dom = 0, same_box = 0;
  double middle[MAX], da = 0, dc = 0;
  double child_dist, archive_dist;
  d = 0;
  ch_flag = 0;
  accept_flag = 0;
  box_func (&newchild);
  for (i = 0; i < archive_size; i++)
    {
      box_func (&archive[i]);

      if (box_dom (archive[i], newchild) == 1)
    {
      accept_flag = -1;
    }
    }

  if (accept_flag == -1)
    return (accept_flag);
  else
    {
      for (i = 0; i < archive_size; i++)
    {
      no_dom = 0;
      if (box_dom (newchild, archive[i]) == 1)
        {
          no_dom++;
          for (int j = i; j < archive_size - 1; j++)
        {
          archive[j] = archive[j + 1];
        }
          archive_size--;
          d = 1;
          i = 0;
        }
    }
      if (d == 1)
    {
      archive_size++;
      archive[archive_size - 1] = newchild;
      accept_flag = 1;
    }
      else
    {
      for (int i = 0; i < archive_size; i++)
        {
          if (same_box_check (newchild, archive[i]) == 1)
        {
          same_box++;
          if (dom_check (newchild, archive[i]) == 1)
            {
              archive[i] = newchild;
              accept_flag = 1;
            }
          else
            {
              if (dom_check (newchild, archive[i]) == 0)	//changed
            accept_flag = -1;
              else
            {
              for (int p = 0; p < MAX; p++)
                {
                  middle[p] = newchild.box[p]*EPSILON[p];	//changed
                }
              child_dist = distance (newchild, middle);
              archive_dist = distance (archive[i], middle);

              if (child_dist < archive_dist)
                {
                  archive[i] = newchild;
                  accept_flag = 1;
                }
              else
                accept_flag = -1;
            }
            }
        }
        }
    }
      if (d == 0 && accept_flag == 0 && same_box == 0)
    {
      archive_size++;
      archive[archive_size - 1] = newchild;

    }

    }

  return (accept_flag);
}

void
generate_replace ()
{
  int tournament (int p1, int p2);
  int child_flag1, child_flag2;
  int ar_parent, pop_parent, ch1_flg = 0, ch2_flg = 0;
  int pop_parent1, pop_parent2;
  double u = 0.0, rnds;
  int x, y, z;
  rnds = randomperc ();
  pop_parent1 = (rnds < 1) ? (int) (rnds * pop_size) : pop_size - 1;
  rnds = randomperc ();
  pop_parent2 = (rnds < 1) ? (int) (rnds * pop_size) : pop_size - 1;
  pop_parent = tournament (pop_parent1, pop_parent2);

  rnds = randomperc ();
  ar_parent = (rnds < 1) ? (int) (rnds * archive_size) : archive_size - 1;

  if (randomperc () <= pxover)
    {
      realcross (population[pop_parent], archive[ar_parent]);
    }
  else
    {
      newchild1 = population[pop_parent];
      newchild2 = archive[ar_parent];
    }

  real_mutate (&(newchild1));
  real_mutate (&(newchild2));
  newchild1.init ();
  newchild2.init ();

}

int
tournament (int p1, int p2)
{
  if (dom_check (population[p1], population[p2]) == 1)
    return p1;
  else if (dom_check (population[p2], population[p1]) == 1)
    return p2;
  else
    {
      if (randomperc () > 0.5)
    return p1;
      else
    return p2;
    }
}


void
compete ()
{
  int flag = 0, lg = 0, pp = 0;
  double rndp;

  for (int i = 0; i < pop_size; i++)
    {
      if (dom_check (newchild, population[i]) == 1)
    {
      population[i] = newchild;
      flag = 1;
      return;
    }
    }
  if (flag == 1)
    return;
  else
    {
      for (int i = 0; i < pop_size; i++)
    {
      if (dom_check (population[i], newchild) == 1)
        {
          lg = -1;
          return;
        }
    }
      if (lg == -1)
    return;
      else
    {

      rndp = randomperc ();
      pp = (rndp < 1.0) ? (int) (rndp * pop_size) : pop_size - 1;
      population[pp] = newchild;
    }
    }
}
