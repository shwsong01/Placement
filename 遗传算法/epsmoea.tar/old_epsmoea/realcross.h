/*This is the file used for crossover for Real Coded GA*/

void realcross (individual parent1, individual parent2);

void
realcross (individual parent1, individual parent2)
{
  int i, j, y, n, r;
  float rnd, par1, par2, chld1, chld2, betaq, beta, alpha;
  float y1, y2, yu, yl, expp;
  /*Loop over no of variables */
  for (j = 0; j < N_of_x; j++)
    {
      /*Selected Two Parents */
      par1 = parent1.xreal[j];
      par2 = parent2.xreal[j];

      yl = infimumx[j];
      yu = supremumx[j];
      rnd = randomperc ();

      /* Check whether variable is selected or not */
      if (rnd <= 0.5)
	{
	  /*Variable selected */
	  //ncross++;

	  if (fabs (par1 - par2) > 0.000001)	// changed by Deb (31/10/01)
	    {
	      if (par2 > par1)
		{
		  y2 = par2;
		  y1 = par1;
		}
	      else
		{
		  y2 = par1;
		  y1 = par2;
		}

	      /*Find beta value */
	      if ((y1 - yl) > (yu - y2))
		{
		  beta = 1 + (2 * (yu - y2) / (y2 - y1));
		  //printf("beta = %f\n",beta);
		}
	      else
		{
		  beta = 1 + (2 * (y1 - yl) / (y2 - y1));
		  //printf("beta = %f\n",beta);
		}

	      /*Find alpha */
	      expp = eeta + 1.0;

	      beta = 1.0 / beta;

	      alpha = 2.0 - pow (beta, expp);

	      if (alpha < 0.0)
		{
		  printf ("ERRRROR %f %d %d %f %f\n", alpha, y, n, par1,
			  par2);
		  exit (-1);
		}

	      rnd = randomperc ();
	      
	      if (rnd <= 1.0 / alpha)
		{
		  alpha = alpha * rnd;
		  expp = 1.0 / (eeta + 1.0);
		  betaq = pow (alpha, expp);
		}
	      else
		{
		  alpha = alpha * rnd;
		  alpha = 1.0 / (2.0 - alpha);
		  expp = 1.0 / (eeta + 1.0);
		  if (alpha < 0.0)
		    {
		      printf ("ERRRORRR \n");
		      exit (-1);
		    }
		  betaq = pow (alpha, expp);
		}

	      /*Generating two children */
	      chld1 = 0.5 * ((y1 + y2) - betaq * (y2 - y1));
	      chld2 = 0.5 * ((y1 + y2) + betaq * (y2 - y1));

	    }
	  else
	    {

	      betaq = 1.0;
	      y1 = par1;
	      y2 = par2;

	      /*Generation two children */
	      chld1 = 0.5 * ((y1 + y2) - betaq * (y2 - y1));
	      chld2 = 0.5 * ((y1 + y2) + betaq * (y2 - y1));

	    }
	  // added by deb (31/10/01)
	  if (chld1 < yl)
	    chld1 = yl;
	  if (chld1 > yu)
	    chld1 = yu;
	  if (chld2 < yl)
	    chld2 = yl;
	  if (chld2 > yu)
	    chld2 = yu;
	}
      else
	{

	  /*Copying the children to parents */
	  chld1 = par1;
	  chld2 = par2;
	}
      newchild1.xreal[j] = chld1;
      newchild2.xreal[j] = chld2;
    }



  return;
}
