
void
input_param ()
{
  cout<<"------------------------------------------------------------\n\n\n";
  cout<<"This is a Multi-Objective GA program based on the Epsilon-Idea\n\n";
  cout<<"To see the algorithm used please refer Towards a Quick ";
  cout<<"\nComputation of Well Spread Pareto-Optimal Solution";
  cout<<"\n       -Deb et. al (EMO-2003 Proceedings) \n";
  cout<<"-----------------------------------------------------------\n";
  cout << "\n\n The number of Decision variables is set in the Code itself.";
  for (int i = 0; i < N_of_x; i++)
    {
      cout <<
	"\n Enter the value of the lower and upper bounds of Decision variable "
	<< i + 1 << " : ";
      cin>>infimumx[i]>>supremumx[i];
    }
  
  cout << "\n Enter the probability of cross-over : ";
  cin >> pxover;

  cout << "\n Enter the mutation probability  : ";
  cin >> p_mutation_real;
      
  cout <<
    "\n Enter the value of the Distribution Index for real-coded crossover : ";
  cin >> eeta;

  cout <<
    "\n Enter the value of the Distribution Index for real-coded mutation : ";
  cin >> n_distribution_m;
}
