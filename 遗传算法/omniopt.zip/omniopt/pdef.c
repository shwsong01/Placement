#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pdef.h"
#include "global.h"

/*# define prob*/

# ifdef prob
void test_problem (double *xreal, double *xbin, int **gene, double *obj, double *constr)
{
	return;
}
# endif
