#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "pdef.h"
#include "global.h"

void pdefinit(void)
{
	return;
}
